﻿using System.Runtime.Intrinsics.X86;

namespace Deelopdracht_3
{
    internal class Program
    {
        //Global variabels
        static string shopName = "Game mania";
        static string username;
        static string password;
        static int item;
        static int amount;
        static bool isAdmin = false;
        static bool keepRunning =true;
        static Random random = new Random();
        static int menuChoice;


        //name array of items
        static string[] nameItemsArray = { "Playstation 5 Slim Disc", "Nintendo Switch Neon Blue & Red", "Desktop Typhon Silver", "Legendary Dragon Decks Unlimited Reprint - Yu-Gi-Oh! TCG", "Quantum 200 Wired Headset - JBL" };
        //stock items array
        static int[] stockItemsArray = { 10, 25, 5, 9, 12 };
        //price items array
        static double[] priceItemArray = { 549.00, 299.00, 399.00, 29.98, 39.98 };
        //info items array
        static string[] infoItemArray = {" De PS5 - console ontketent nieuwe gamingmogelijkheden die je nooit had verwacht.","De Nintendo Switch biedt je de kans om dezelfde games te spelen waar, wanneer en met wie je wil. " +
                    "De Nintendo Switch combineert de flexibiliteit van een handheld-systeem met de kracht van een systeem voor thuis, wat gloednieuwe manieren biedt om games te spelen.",
                "De Typhon Silver desktop is perfect voor de startende gamer. De computer heeft geen losse videokaart maar maakt slim gebruik van een processor met geïntegreerde videochip.Hiermee kun je besparen en alsnog je games op launch settings spelen. De betrouwbare Intel Dual Core processor zal in combinatie met de supersnelle M.2 SSD ervoor zorgen dat Windows 11 en de games snel opstarten.De voeding is (80 plus) gecertificeerd voor optimale efficiëntie en is zuinig in verbruik. Met de RGB verlichting creëer je de ultieme look en game-ervaring. Zeer geschikt om uit te breiden.",
                "Zeer weinig monsters zijn zo populair en direct herkenbaar als de vele draken uit de Yu-Gi-Oh! Trading Cad Game! Of ze nu magisch, mechanisch of multidimensionaal zijn, draken vangen de harten en geesten van duelisten overal terwijl ze hun tegenstanders op het duellerende veld decimeren.Duelisten kunnen 3 unieke decks in handen krijgen met enkele van de meest angstaanjagende draken van de game, en kaarten om elk van hen te versterken in legendarische Dragon Decks!",
                "Maak van gamen een groots avontuur. De JBL Quantum 200-headset met JBL QuantumSOUND Signature plaatst je in het hart van de actie.Meeslepend en nauwkeurig zodat je zelfs de kleinste details kunt horen. Met de JBL Quantum 200 heb je alles om elke battle te winnen. De echoonderdrukkende microfoon met stemfocus en opklapbare dempfunctie zorgt voor duidelijke multiplayerinteracties,terwijl je met oorkussens van traagschuim urenlang comfortabel kunt gamen. Eersteklas materialen zorgen ervoor dat je headset lang meegaat. Met de JBL Quantum 200-headset haal je maximale beleving in huis." };

        static string[,] logo =
     {
     { "+", "-", "-", "-", "-", "-", "-", "-", "-", "-", "+", " " },
    { "|", " ", " ", "G", "A", "M", "E", " ", " ", " ", "|", " " },
    { "|", " ", "M", "A", "N", "I", "A", " ", " ", " ", "|", " " },
    { "|", " ", " ", " ", " ", " ", " ", " ", " ", " ", "|", " " },
    { "|", " ", " ", " ", " ", " ", " ", " ", " ", " ", "|", " " },
    { "|", " ", " ", " ", " ", " ", " ", " ", " ", " ", "|", " " },
    { "|", " ", " ", " ", " ", " ", " ", " ", " ", " ", "|", " " },
    { "+", "-", "-", "-", "-", "-", "-", "-", "-", "-", "+", " " }
};

        static string[] reviews =
       {
    "“Ik vond alle nieuwe games die ik zocht, zonder uit mijn ananas te hoeven komen!” – SpongeBob SquarePants",
    "“Supersnelle levering! Zelfs ik kon het niet bijhouden.” – Sonic the Hedgehog",
    "“Eindelijk een plek waar ik lasagne én mijn favoriete games kan krijgen. Oké, misschien geen lasagne.” – Garfield",
    "“Game Mania is magisch! Zelfs Elsa zou hier haar games kopen.” – Olaf de sneeuwpop",
    "“De beste winkel voor retro-games. Het brengt me terug naar de goede oude dagen!” – Mickey Mouse",
    "“Het is niet alsof ik ooit plezier heb, maar Game Mania maakt het tenminste draaglijk.” – Squidward Tentacles",
    "“Mijn favoriete plek om nieuwe en oude consoles te vinden. Eenvoudig en betrouwbaar!” – Woody (Toy Story)",
    "“Het personeel van Game Mania is net zo behulpzaam als mijn vrienden in het Honderd Bunderbos!” – Winnie de Poeh",
    "“De aanbiedingen op accessoires zijn fantastisch. Ik kreeg een controller die zelfs op Krusty’s salaris past!” – Homer Simpson",
    "“Ik weet niet hoe ik hier kwam, maar ik kocht een geweldige game!” – Patrick Star",
     "“Het motto van Game Mania: ‘Om gamers te dienen, en plezier te brengen naar de sterren!’” – Jessie & James (Team Rocket)"};


        static string GetRandomReview()
        {

            int randomIndex = random.Next(0, reviews.Length);
            return reviews[randomIndex];
        }

        static void PrintRandomReview()
        {
            string review = GetRandomReview();
            Console.WriteLine();
            Console.WriteLine(review);
            Console.WriteLine();

        }
        static void GetGameManiaLogo()
        {
            Console.WriteLine();
            for (int i = 0; i < logo.GetLength(0); i++)
            {
                for (int j = 0; j < logo.GetLength(1); j++)
                {
                    Console.Write(logo[i, j]);
                }
                Console.WriteLine();
            }
        }

        static void UserName()
        {
            Console.Write("Welkom gebruiker, Geef u gebruikersnaam: ");//asking name.
            username = Console.ReadLine();
            Console.WriteLine();

        }
        static void Password()
        {
            Console.WriteLine("Geef het wachtwoord");
            password = Console.ReadLine();
        }

        static void Greeting()
        {
            GetGameManiaLogo();

            UserName();

            Console.ForegroundColor = ConsoleColor.Yellow;//Changing color to yellow.
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine($"Hallo, {username} en welkom bij {shopName}. {shopName} verkoopt Computers, laptops,videogames,card games en Consoles.");
            Console.ResetColor();//Reset the color back to white.


        }

        static void ShowItem(int item)
        {
            ShowAllItem();
            Console.WriteLine();
            Console.WriteLine("Welke product wilt u bekijken?");
            Console.WriteLine();
            Console.Write("Invoer van de gebruiker:");

            item = Convert.ToInt32(Console.ReadLine()) - 1;
            Console.WriteLine($"Naam = {nameItemsArray[item]}, Stock = {stockItemsArray[item]}, Prijs = {priceItemArray[item]} ");
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine($" Info product: {infoItemArray[item]}");
            Console.WriteLine();
            Console.WriteLine("Druk op enter op verder te gaan");
            Console.ReadLine();
            Console.Clear();
        }
        static void ShowAllItem()
        {
            for (int i = 0; i < nameItemsArray.Length; i++)
            {
                Console.WriteLine($"Item {i + 1}: Naam = {nameItemsArray[i]}, Stock = {stockItemsArray[i]}, Prijs = {priceItemArray[i]} ");
                Console.WriteLine();
                Console.WriteLine($"Beschrijving = {infoItemArray[i]}");
                if (i < nameItemsArray.Length - 1)
                {
                    Console.WriteLine("--------------------------------------------------");
                }
            }
        }
        static void buyItem(int item, int amount)
        {
            Console.WriteLine();
            Console.WriteLine("Maak uw keuze van welke item u wilt kopen.");
            Console.Write("Invoer van de gebruiker: ");

            item = Convert.ToInt32(Console.ReadLine()) - 1;
            Console.WriteLine();
            if (item < stockItemsArray.Length)
            {
                Console.WriteLine($"Gekozen product = {nameItemsArray[item]}, in stock {stockItemsArray[item]} ");

                Console.WriteLine("Hoeveel stuks wilt u kopen?");
                Console.Write("Invoer van de gebruiker: ");
                amount = Convert.ToInt32(Console.ReadLine());

                if (amount <= stockItemsArray[item])
                {
                    double priceInputBuy1 = priceItemArray[item] * amount;
                    double VatAmount = priceInputBuy1 * 0.21;
                    double totalAmount = priceInputBuy1 + VatAmount;

                    stockItemsArray[item] -= amount;

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Er zijn genoeg artikelen in stock. U hebt {amount} artikelen succesvol betaald.");
                    Console.ResetColor();
                    Console.WriteLine($"Zonder btw is het bedrag {priceInputBuy1:f2} euro. De btw bedraagt 21%, wat neerkomt op {VatAmount:f2} euro.");
                    Console.Write($"Het volledig bedrag komt uit op {priceInputBuy1:f2}euro => ");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"{totalAmount:f2}euro.");
                    Console.WriteLine();
                    Console.ResetColor();

                }
                else if (stockItemsArray[item] == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Uitverkocht");
                    Console.WriteLine();
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Niet voldoende in stock");
                    Console.ResetColor();
                    Console.WriteLine();

                }
            }
            Console.WriteLine("Druk op enter op verder te gaan");
            Console.ReadLine();
            Console.Clear();
        }

        static void adminAcces(string username, string password)
        {
            string passwordAdmin = "Admin1234";//password for admin is Admin1234
            int count = 1;
            do
            {
                Console.WriteLine($"Poging {count} van 3.");

                Console.Write("Geef het passwoord voor toegang als beheerder: ");//Checking password
                password = Console.ReadLine();//storing check password.
                if (passwordAdmin == password)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Passwoord is juist!");
                    Console.WriteLine($"{username} is nu admin");
                    Console.ResetColor();
                    isAdmin = true;
                    Console.WriteLine();
                }
                else if (count >= 3)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Je hebt al je pogingen opgebruikt. Toegang geweigerd.");

                    Console.ResetColor();
                    Console.WriteLine();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Passwoord is fout");
                    Console.ResetColor();
                    Console.WriteLine();
                }
                

                count++;
            } while (count <= 3 && passwordAdmin != password);

            Console.WriteLine("Druk op enter op verder te gaan");
            Console.ReadLine();
            Console.Clear();
        }

        static void IsAdmin()
        {
            if (isAdmin)
            {
                Console.Write("Welk item wilt u bijvullen?");
                Console.WriteLine();

                for (int i = 0; i < stockItemsArray.Length; i++)
                {
                    Console.WriteLine($"Item {i + 1}: Naam = {nameItemsArray[i]}, Huidige voorraad = {stockItemsArray[i]} stuks.");
                }


                Console.WriteLine("Maak een keuze voor welk item u wilt bijvullen.");
                Console.Write("Invoer van de gebruiker: ");

                item = Convert.ToInt32(Console.ReadLine()) - 1;

                if (item < stockItemsArray.Length)
                {
                    Console.WriteLine($"Hoeveel stuks wilt u toevoegen aan {nameItemsArray[item]}? Er zijn {stockItemsArray[item]} stuks in stock");
                    Console.Write("Invoer van de gebruiker: ");
                    int addStock = Convert.ToInt32(Console.ReadLine());

                    //adding 
                    stockItemsArray[item] += addStock;

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Voorraad bijgewerkt! Er zijn nu {stockItemsArray[item]} stuks van {nameItemsArray[item]} in voorraad.");
                    Console.ResetColor();
                    Console.WriteLine();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Ongeldige keuze.");
                    Console.ResetColor();
                }

                Console.WriteLine("Druk op enter op verder te gaan");
                Console.ReadLine();
                Console.Clear();

            }
            else
            {
                Console.WriteLine("Onbekende keuze");
            }

        }

        static void Endprogram()
        {
            keepRunning = false;
            Console.WriteLine("Every farewell is a new beginning; your journey awaits!"); ;
            Console.WriteLine("Druk op enter om te sluiten.");
            Console.ReadKey();
            Console.Clear();
        }

        static void DisplayMenu()
        {
           

            Console.WriteLine();
            Console.WriteLine("Maak u keuze tussen");
            Console.WriteLine("Druk op 1 om onze producten te bekijken.");
            Console.WriteLine("Druk op 2 om onze producten te kopen.");
            Console.WriteLine("Druk op 3 voor admin toegang .");
            Console.WriteLine("Druk op 4 om te stoppen");

            if (isAdmin)
            {
                Console.WriteLine("Druk op 5 om de stock te veranderen");
            }
            PrintRandomReview();
            Console.Write("Invoer van de gebruiker: ");

            menuChoice = Convert.ToInt32(Console.ReadLine());//asking user input for switch.


            Console.Clear();//Clearing screen
        }

        static void ShowMenu()
        {

            while (keepRunning)
            {
                DisplayMenu();

                switch (menuChoice)
                {

                    case 1:
                        ShowAllItem();
                        ShowItem(item);

                        break;

                    case 2:
                        ShowAllItem();
                        buyItem(item, amount);
                        break;

                    case 3:
                        adminAcces(username, password);

                        break;
                    case 4:
                        Endprogram();
                        break;

                    case 5:

                        IsAdmin();


                        break;
                    default:
                        Console.WriteLine("Onbekende keuze");
                        break;

                }
            }

        }

            static void Main(string[] args)
            {

                Greeting();
                ShowMenu();
            }
        

    }
}